<footer class="bg-dark text-white text-center py-4 mt-5">
    <div class="container">
        <p class="mb-1">&copy; <?php echo e(date('Y')); ?> FitnessFrick. All rights reserved.</p>
        <small>Empowering your health journey with technology.</small>
    </div>
</footer>
<?php /**PATH E:\Fitness_System\resources\views/partials/footer.blade.php ENDPATH**/ ?>