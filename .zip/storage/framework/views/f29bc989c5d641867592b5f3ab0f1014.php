<header>
    <a href="#" class="logo"><span>Fitness</span>Frick</a>
    <div class='bx bx-menu' id="menu-icon"></div>
    <ul class="navbar">
        <li><a href="#home">Home</a></li>
        <li><a href="#services">Services</a></li>
        <li><a href="#about">About Us</a></li>
        <li><a href="#plans">Pricing</a></li>
        <li><a href="#review">Review</a></li>
    </ul>
    <div class="top-btn">
        <a href="<?php echo e(route('register')); ?>" class="nav-btn">Join Us</a>
    </div>
</header>
<?php /**PATH E:\Fitness_System\resources\views/inc/navbar.blade.php ENDPATH**/ ?>